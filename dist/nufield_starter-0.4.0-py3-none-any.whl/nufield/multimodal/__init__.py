"""Multimodal feature fusion primitives."""
