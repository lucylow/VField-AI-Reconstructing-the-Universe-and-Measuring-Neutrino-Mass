"""Compute-planning helpers."""
