"""Miscellaneous small utilities."""
