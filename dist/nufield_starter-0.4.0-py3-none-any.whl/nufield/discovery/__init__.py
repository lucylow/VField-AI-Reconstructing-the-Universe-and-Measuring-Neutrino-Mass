"""Constrained experiment-search scaffolding."""
